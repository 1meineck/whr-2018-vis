var d = [

	{
		name:"Data Set",
		skills:[
			{axis:"Freedom",value:3.00},
			{axis:"Corruption",value:3.0},
			{axis:"Generosity",value:3.00},
			{axis:"Dystopia",value:3.00},
			{axis:"GDP",value:3.00},
			{axis:"Life Expectancy",value:3.00},
			{axis:"Social Support",value:3.00},
			
		
			
			
		  ],
	}
];